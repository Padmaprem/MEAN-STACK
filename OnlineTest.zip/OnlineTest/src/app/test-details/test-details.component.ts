import { Component, OnInit } from '@angular/core';
import { testService } from '../test.service';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-test-details',
  templateUrl: './test-details.component.html',
  styleUrls: ['./test-details.component.css']
})
export class TestDetailsComponent implements OnInit {
  alert: boolean = false;
  testdata = new FormGroup({
    1: new FormControl(''),
    2: new FormControl(''),
    3: new FormControl(''),
    4: new FormControl(''),
    5: new FormControl(''),
       
  });

  
  constructor(private test:testService) { }

  ngOnInit(): void {
  }
  
//collectDataDetails1() {
  //    
  //this.test.savetestdetails(this.testdata.value).subscribe((result:any) => {
    //console.warn("The result is here", result)
 // })
  //this.alert=true
  //to clear the form
  //this.testdata.reset({})
//}
closeAlert()
{
  this.alert=false;
}
}
