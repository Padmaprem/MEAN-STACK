import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { ListDataComponent } from './list-data/list-data.component';
import {PageNotFoundComponent} from './pageNotFoundComponent';
import {HomeComponent} from './home/home.component';
import { TestDetailsComponent } from './test-details/test-details.component';
import { LoginComponent } from './login/login.component';

//If your application consists of many components, then it takes a long time to load all components when an app is downloaded, which degrades the user experience.
const routes: Routes = [{ component: HomeComponent, path: "" },{ component: SignupComponent, path: "adddata" },
{ component: ListDataComponent, path: "listdata" },{ component: TestDetailsComponent, path: "testdata" },
{path : 'logindata', component : LoginComponent},{path:"**",component:PageNotFoundComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
