import { TestBed } from '@angular/core/testing';

import { testService } from './test.service';

describe('testService', () => {
  let service: testService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(testService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
