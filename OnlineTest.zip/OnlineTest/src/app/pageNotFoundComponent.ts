import {Component} from '@angular/core';
@Component({
  selector:"<app-PageNotFound>",
  template:`<h1>Sorry! you are requested page  does not exist</h1>`
})
export class PageNotFoundComponent{

}
