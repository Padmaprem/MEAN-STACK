import { Component, OnInit } from '@angular/core';
import { testService } from '../test.service';
import { FormGroup,FormControl } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  alert: boolean = false;
  addtest = new FormGroup({
    name: new FormControl(''),
    contactNo:new FormControl(''),
    email: new FormControl(''),
    address: new FormControl(''),
    username: new FormControl(''),
    password: new FormControl(''),

  });
  
    constructor(private test: testService) { }
  
    ngOnInit(): void {
    }
    collecttest() {
      //console.log(this.addtest.value)
      this.test.savetest(this.addtest.value).subscribe((result) => {
        console.warn("The result is here", result)
      })
      this.alert=true
      //to clear the form
      this.addtest.reset({})
    }
    closeAlert()
    {
      this.alert=false;
    }
  }
  
