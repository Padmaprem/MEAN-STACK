import { Component, OnInit } from '@angular/core';
import { testService } from '../test.service'

@Component({
  selector: 'app-list-data',
  templateUrl: './list-data.component.html',
  styleUrls: ['./list-data.component.css']
})
export class ListDataComponent implements OnInit {

  constructor(private testS: testService) { }
  collection: any = [];
  ngOnInit(): void {
    this.testS.getList().subscribe(result => {

      //Array.of converts object into array
      this.collection = Array.of(result);
    })
  }
  deletetest(item:any) {
    this.collection.splice(item - 1, 1)
    this.testS.deletetest(item).subscribe(result => {
      console.warn("result", result)
      //we call the below code to get updated list
      this.testS.getList().subscribe(result => {
        //Array.of converts object into array
        this.collection = Array.of(result);
        //console.warn(this.collection[0])
      })
    })
  }
}
